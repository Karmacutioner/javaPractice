// Homework 3
// Luke Burgie
// May 31 2024
// CSC1060
//Lottery Game

import java.util.Random;  //for random number generation
import java.util.Scanner; // for keyboard input

public class Main
{
	public static void main(String[] args) {
	   //Generates 3 random numbers betwwen 0 and 9  
	   Random randGen = new Random(); 
	   int lottoNumOne = randGen.nextInt(10);
	   int lottoNumTwo = randGen.nextInt(10);
	   int lottoNumThree = randGen.nextInt(10);
	   
	   //Header
	   System.out.println("Welcome to the lottery!");
	   System.out.println("One number correct                    $10");
	   System.out.println("Two numbers correct                  $100");
	   System.out.println("Three numbers correct               $1000");
	   System.out.println("Three numbers in correct order $1,000,000");
	   
	   //Takes player inputs
	   Scanner input = new Scanner(System.in);
		    System.out.println("Pick your first number 0-9");
		    int userGuessOne = input.nextInt(); 
	        System.out.println("Pick your second number 0-9");
		    int userGuessTwo = input.nextInt(); 
	        System.out.println("Pick your third number 0-9");
		    int userGuessThree = input.nextInt(); 
	   
	   //Displays lottoNums and userGuesses 
	   System.out.print("Lottery Numbers: ");
	   System.out.print(lottoNumOne);
	   System.out.print(" ");
	   System.out.print(lottoNumTwo);
	   System.out.print(" ");
	   System.out.print(lottoNumThree);
	   System.out.print(" ");
	   System.out.print("  Your Numbers: ");
	   System.out.print(userGuessOne);
	   System.out.print(" ");
	   System.out.print(userGuessTwo);
	   System.out.print(" ");
	   System.out.println(userGuessThree);
	  
	   //Compares userGuess and lottoNum variables, displays results
	   int match = 0; //variable to track number of matches 
	   int guessRepeat = 0; //variable to track repeat matches
	   
	   if ((lottoNumOne == userGuessOne) && (lottoNumTwo == userGuessTwo) && (lottoNumThree == userGuessThree)) {
	       //Checks for all matching numbers
	       System.out.print("Perfect match! Win $1,000,000");
	       
	       
	   }
	   else  {
	  
	       if (lottoNumOne == userGuessOne)  {
	           //Checks for lottoNumOne match 
	           match += 1;
	           if (userGuessOne == userGuessTwo){
	               // checks for repeat guess
	               guessRepeat += 1;
	               
	           }
	           if (userGuessOne == userGuessThree){
	               // checks for repeat guess
	               guessRepeat += 1;
	           }
	           
	           
	           }
	       
	       if (lottoNumOne == userGuessTwo) {
	           match +=1;
	           if (userGuessTwo == userGuessOne){
	               // checks for repeat guess
	               guessRepeat += 1;
	           }
	           if (userGuessTwo == userGuessThree){
	               // checks for repeat guess
	               guessRepeat += 1;
	           }
	       
	           
	       }
	       if (lottoNumOne == userGuessThree) {
	           match +=1;
	           if (userGuessThree == userGuessOne){
	               // checks for repeat guess
	               guessRepeat += 1;
	               
	           }
	           if (userGuessThree == userGuessTwo)
	               // checks for repeat guess
	               guessRepeat += 1;
	      
	       }
	       
	       if (lottoNumTwo == userGuessOne) {
	           //Checks for lottoNumTwo match
	           match += 1;
	           if (userGuessOne == userGuessTwo){
	               // checks for repeat guess
	               guessRepeat += 1;
	               
	           }
	           if (userGuessOne == userGuessThree){
	               // checks for repeat guess
	               guessRepeat += 1;
	           }
	           
	       }
	       if (lottoNumTwo == userGuessTwo) {
	           match += 1;
	           if (userGuessTwo == userGuessOne){
	               // checks for repeat guess
	               guessRepeat += 1;
	           }
	           if (userGuessTwo == userGuessThree){
	               // checks for repeat guess 
	               guessRepeat += 1;
	           }
	      
	       }
	       if (lottoNumTwo == userGuessThree){
	           match +=1;
	           if (userGuessThree == userGuessOne) {
	               // checks for repeat guess
	               guessRepeat += 1;
	               
	           }
	           if (userGuessThree == userGuessTwo){
	              // checks for repeat guess
	              guessRepeat += 1;
	           
	           }
	      
	       }
	       
	       if (lottoNumThree == userGuessOne) {
	           //Checks for lottoNumThree match
	           match += 1;
	           if (userGuessOne == userGuessTwo){
	               // checks for repeat guess
	               guessRepeat += 1;
	               
	           }
	           if (userGuessOne == userGuessThree){
	               // checks for repeat guess
	               guessRepeat += 1;
	           }
	   
	       }
	       if (lottoNumThree == userGuessTwo) {
	           match += 1;
	           if (userGuessTwo == userGuessOne){
	               // checks for repeat guess
	               guessRepeat += 1;
	           }
	           if (userGuessTwo == userGuessThree){
	               // checks for repeat guess
	               guessRepeat += 1;
	           }
	       }
	       if (lottoNumThree == userGuessThree) {
	           match +=1;
	           if (userGuessThree == userGuessOne){
	               // checks for repeat guess
	               guessRepeat += 1;
	               
	           }
	           if (userGuessThree == userGuessTwo)
	              // checks for repeat guess
	              guessRepeat += 1;
	      
	       }
	       
	       
	       
	       if (guessRepeat > 0 ) {
	           if ((userGuessOne == userGuessTwo) && (userGuessTwo == userGuessThree)) {
	               //Adjusts guessRepeat variable if all userGuess variables are equal
	               guessRepeat = guessRepeat / 3; 
	           }
	           else {
	               //Adjusts guessRepeat if only 2 userGuess variables are equal
	               guessRepeat = guessRepeat / 2;
	           }
	         
	       }
	       
	       // calculates correct number of matches if repeat guesses exist
	       match -= guessRepeat; 
	       
	       
	       
	            
	       
	       //Adjusts match variable to compensate for when all lottoNum variables are equal 
	       if ((match > 1) && (lottoNumOne == lottoNumTwo) && (lottoNumTwo == lottoNumThree)) {
	             //Adjusts for when all userGuess variables are not equal 
	             if ((userGuessOne != userGuessTwo) && (userGuessOne != userGuessThree) && (userGuessTwo != userGuessThree)) {
	                 match -= 2;
	             }
	             //Ajusts for when only 2 userGuess variables are equal
	             if ((userGuessOne == userGuessTwo)  || (userGuessOne == userGuessThree) || (userGuessTwo == userGuessThree)) {
	                 match -= 1;
	             
	               //If all userGuess variables are equal in this situaton program will result in perfect match or No matches, additional adjustment mot needed  
	             }
	       }
	            
	            
	       //Ajusts match variable to compensate for when only 2 lottoNum variables are equal
	       if ((match > 1) && ((lottoNumOne == lottoNumTwo) || (lottoNumOne == lottoNumThree) || (lottoNumTwo == lottoNumThree))) {
	             
	             //Adjusts for when all userGuess variables are not equal
	             if ((userGuessOne != userGuessTwo) && (userGuessOne != userGuessThree) && (userGuessTwo != userGuessThree)) {
	                 match -= 1;
	             }
	             //Ajusts for when only 2 userGuess variables are equal
	             if ((userGuessOne == userGuessTwo)  || (userGuessOne == userGuessThree) || (userGuessTwo == userGuessThree)) {
	                 match -= 0;
	             }
	               
	            }     

	       //System.out.println(match); //used to test variable
 	       
 	       //System.out.println(guessRepeat); //usesd to test variable
 	       
 	       //Determines output based on match variable
 	       switch (match){
 	           case 0:
 	               System.out.print("Sorry, no matches.");
 	               break;
 	           case 1:
 	               System.out.print("One match, win $10!");
 	               break;
 	           case 2:
 	               System.out.print("Two matches, win $100!");
 	               break;
 	           case 3:
 	               System.out.print("Three matches, win $1000!");
 	               break;
 	           
 	       }
 	        
 	    }    
	   
	   
	   
	   
	   
	   //System.out.print(lottoNumOne);
	   //System.out.print(lottoNumTwo);
	   //System.out.print(lottoNumThree);
	
	    
	}
}
