//Homework 1 Luke Burgie
public class Main
{
	public static void main(String[] args) {
		System.out.println("My name is Luke Burgie");
		System.out.println("My address is 1537 South Fountain Street, Colorado Springs,CO 80910");
		System.out.println("My number is 719-757-0496");
		System.out.println("My major is computer science");
	}
}
