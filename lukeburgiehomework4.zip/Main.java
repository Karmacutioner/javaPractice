// Homework 4
// Luke Burgie
// May 31 2024
// CSC1060
// Amortization calculator 

import java.util.Scanner; // for keyboard input
import java.lang.Math; // for math funtions


public class Main
{
	public static void main(String[] args) {
	
	//Takes loan info
	Scanner input = new Scanner(System.in);
		System.out.println("What is the loan amount?");
		double loanAmount = input.nextDouble();
		final double STARTING_Loan_AMOUNT = loanAmount;
		
		System.out.println("What is the annual intrest rate? ");
		double annualIntrestRate = input.nextDouble();
		double termIntrestRate = (annualIntrestRate / 100) / 12;
		
		System.out.println("How many years will it take to pay off the loan?");
		double loanTermYears = input.nextDouble();
		double loanTermMonths = loanTermYears * 12;
	    
	    //initaial monthy payment calculation
	    double loanTimesRate = termIntrestRate * loanAmount;
		double payment = loanTimesRate/ (1-(Math.pow((1 + termIntrestRate),(-1 * loanTermMonths))));
		
		//Header with loan info
		System.out.println("");
		System.out.print("Intrest rate per period: ");
		System.out.println(String.format("%.6f", termIntrestRate));
		System.out.println("");
		System.out.print("Number of payments: ");
		System.out.println(loanTermMonths);
		System.out.println("");
		System.out.print("Payment: ");
		System.out.println(String.format("%.2f", payment));
		System.out.print("");
		System.out.println("Payment    Balance      to Principle    to Intrest");
		
		//creates counter for payments
		int paymentCounter = 1;
		
		//creates variable to track Intrest payments
		double totalIntrest = 0;
		
		//Calculates loan Amortization info
		while (loanTermMonths > 0){
		     loanTimesRate = termIntrestRate * loanAmount;
		     payment = loanTimesRate/ (1-(Math.pow((1 + termIntrestRate),(-1 * loanTermMonths))));
		     
		     //outputs loan Amortization info
		     System.out.print(paymentCounter);
		     System.out.print("          ");
		     System.out.print(String.format("%.2f", loanAmount ));
		     System.out.print("      ");
		     System.out.print(String.format("%.2f", (payment - loanTimesRate)));
		     System.out.print("         ");
		     System.out.println(String.format("%.2f", loanTimesRate));
	
	         loanAmount -= ( payment - loanTimesRate ); // subtracts princpal payment from loan balance
		     loanTermMonths -= 1;                       // subtracts one payment off loan term
		     paymentCounter += 1;                       // adds one payment to payments counter
	         totalIntrest += loanTimesRate;             // adds intrest payment to totalIntrest
		}
		double totalPayed = STARTING_Loan_AMOUNT + totalIntrest;
		System.out.print("Toatl amount payed: ");
		System.out.print(String.format("%.2f", totalPayed));
	
	}
}
