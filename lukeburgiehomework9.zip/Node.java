import java.util.LinkedList;

public class Node{
    
    private Integer index;
    private Node prev;
    private Node next;
    
    Node(Integer index, Node prev,Node next){
        this.index = index;
        this.prev = prev;
        this.next = next;
        
    }//end constructor
    
    public int getIndex(){
        return index;
    }//end getIndex()
    
    
    public void setIndex(int index){
        this.index = index;
    }//end setIndex
    
    
    public Node getPrev(){
        return prev;
    }//end getprev()
    
    
    public void setPrev(Node prev){
        this.prev = prev;
    }//end setPrev()
    
    
    public Node getNext(){
        return next;
    }//end getNext()
    
    public void setNext(Node next){
        this.next = next;
    }//end setNext() 
    
    
    
    
}//end class