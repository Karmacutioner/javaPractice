//Homework 9
//Luke Burgie
//July 4 2024
//CSC1060
//Table

import java.util.LinkedList;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;

public class Main
{
	public static void main(String[] args) throws IOException {
	    
	    demographicLL list = new demographicLL();
		
		//opens file
        Scanner scnr = new Scanner(System.in);
		FileInputStream fileByteStream = null;
		Scanner inFS = null;
		fileByteStream = new FileInputStream("demographicInfo.dat");
		inFS = new Scanner(fileByteStream);
		
		//copies demographicInfo.dat into linkedlist
		while (inFS.hasNextLine()){
		    String lineItem = inFS.nextLine();
		    String [] data = lineItem.split(","); 
		    
		    for (String val: data) {
		        list.add(val);
		    }//end for loop
		    
		}//end while loop
		
		//close file
		fileByteStream.close();
		
		//print header
		System.out.printf("%-9s %12s %5s %8s %10s %20s %20s %20s %8s %8s%n","Last","First","Age","Sex","Status","Occupation","Street","City","State","Zip");
		
	   //counter for while loop
	   int i = 0;
	   
	   while (i < list.size()){
	    String firstName = list.get(i);
		    i++;
		    String lastname = list.get(i);
		    i++;
		    String age = list.get(i);
		    i++;
		    String sex = list.get(i);
		    i++;
		    String maritalStauts = list.get(i);
		    i++;
		    String occupation = list.get(i);
	        i++;
	        String streetAddress = list.get(i);
	        i++;
	        String city = list.get(i);
		    i++;
		    String state = list.get(i);
		    i++;
		    String zipCode = list.get(i);
		    i++;
		    
		   //creates object to hold demographic data
		   info demInfo = new info(firstName,lastname,age,sex,maritalStauts,occupation,streetAddress,city,state,zipCode);
		   
		   //prints demographic data
		   demInfo.printInfo();
		}//end while loop
		
		
	
	    
	}//end class
}//end main
