import java.util.*;

public class info{
    
    //demographic info variables
    private String firstName;
    private String lastName;
    private String age;
    private String sex;
    private String maritalStatus;
    private String occupation;
    private String steetAddress;
    private String city;
    private String state;
    private String zipCode;

    //node
    public info next;
    
    info(String firstName, String lastName,String age, String sex,String maritalStatus,String occupation,String steetAddress, String city,String state,String zipCode){
      this.firstName = firstName;
      this.lastName = lastName;
      this.age = age;
      this.sex = sex;
      this.maritalStatus = maritalStatus;
      this.occupation = occupation;
      this.steetAddress = steetAddress;
      this.city = city;
      this.state = state;
      this.zipCode = zipCode;
    }//end info constructor
    
    public void printInfo(){
        
        System.out.printf("%-9s %12s %5s %8s %10s %20s %20s %20s %8s %8s%n",lastName,firstName,age,sex,maritalStatus,occupation,steetAddress,city,state,zipCode);
        
        
    }//end printInfo
    
     @Override
      public String toString() {
      return lastName;
  }

    
    
}//end class