import java.util.LinkedList;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;


public class demographicLL{
    
    private Node first;
    private Node current;
    private Node last;
    private int currentIndex;
    private int numElements;
    
    public LinkedList<String> infoList = new LinkedList<>();
    
    public demographicLL(){
        this.first = null;
        this.last = null;
        this.numElements = 0;
        this.current = null;
        this.currentIndex = -1;
        
    }//end demographicLL constuctor
    
    public void add(String lineItem){
        infoList.add(lineItem);
        int size = infoList.size();
        //System.out.println(size);
    }//end add method
    
    
    public int size(){
        
        int size = infoList.size();
        return size;
    }//end size
    
    public String get(int i){
        String item = infoList.get(i);
        return item;
    
        
    }//end get
    

    
    
    
}//end class