// Homework 6
// Luke Burgie
// June 26 2024
// CSC1060
// GPS cordinate converion 

//for keyboard input
import java.util.Scanner;

import java.lang.Math; // for math funtions

public class Main
{
    //Displays main menu
    public static void displayMenu(){
        System.out.println("This progarm converts between 2 GPS coordinate systems.");
		System.out.println("1: degrees, minutes and seconds with a cardinal direction (N, S, E W) to decimal degrees");
		System.out.println("2: decimal degrees to degrees, minutes and seconds with a cardinal direction (N, S, E, W");
    
        //Takes menu selection
        Scanner menuInput = new Scanner(System.in);
        int convertOption = 0;
        while ((convertOption != 1) && (convertOption != 2)){
           System.out.print("Your menu selection is: ");
           convertOption = menuInput.nextInt();
           
        }
         if (convertOption == 1){ 
	     toDecimalDegrees();
	          }//end convertOption if statement
       
        else if (convertOption == 2){
            toDegrees();
        }//end convertOption else if 
    
        
    }//End displayMenu
    
    
    public static double toDecimalDegrees(){
        Scanner convertInput = new Scanner(System.in);
        double degrees = -1.0;
        while ((degrees <= 0.0) || (degrees >= 180.0)){
          System.out.print("Enter the degrees 0 to 180:");
          degrees = convertInput.nextDouble();
          
        
            
        }//ends degrees input loop
        
        double minutes = -1.0;
        while ((minutes <= 0.0) || (minutes >= 60.0)){
            System.out.print("Enter the minutes 0 to 60:");
            minutes = convertInput.nextDouble();
        }//ends minutes input loop
        
        double seconds = -1.0;
        while ((seconds <= -1.0) || (seconds >= 60.0)){
            System.out.print("Enter the seconds 0 to 60:");
            seconds = convertInput.nextDouble();
        }// ends seconds input loop
        
        //converts cordinates to decimalDegrees
        double decimalDegrees = degrees + (minutes/60) + (seconds/60);
        
        //output
        Scanner directionInput = new Scanner(System.in);
	     System.out.print("Enter the cardinal direction (N,E,S, or W:");
	     String direction = directionInput.nextLine();
	     System.out.println(decimalDegrees);
        
        
        return decimalDegrees;
        
        
    }//End toDecimalDegrees
	
	
	public static double toDegrees(){ 
	   
	   //takes decimalDegrees input
	    Scanner convertInput = new Scanner(System.in);
	    System.out.print("Enter the decimal degrees 0 180:");
	    double decimal = convertInput.nextDouble();
	    
	     //converts to corrdiantes 
	     double degrees = Math.floor(decimal);
	     double minutes = Math.floor((decimal - degrees) * 60);
	     double seconds = (decimal - degrees - (minutes/60)) * 3600;
	     
	     //convets double to int
	     int intDegrees = (int)degrees;
	     int intMinutes = (int)minutes;
	     
	     //output
	     System.out.println();
	     System.out.print(intDegrees);
	     System.out.print(" ");
	     System.out.print(intMinutes);
	     System.out.print(" ");
	     System.out.println(seconds);
	
	  return degrees;  
	}//end toDegrees
	
	
	public static void main(String[] args) {
	   
	   Scanner repeatInput = new Scanner(System.in);
	   
	   int repeat = 1;
	   
	   while (repeat == 1){
	        
	        displayMenu();
	        
	        System.out.print("Would you like to try another? Y or N ");
	        char yesNo = repeatInput.next().charAt(0);
	        if ((yesNo == 'Y') || (yesNo == 'y')){
	            repeat = 1;
	        }//end if yesNo statement
	        else {
	            repeat = 0;
	            System.out.print("End Program");
	        }//end yesNo else statement 
	            
	        }//end while repeat loop
	        
	 
	   
	  

	}//end main    
}//end class


