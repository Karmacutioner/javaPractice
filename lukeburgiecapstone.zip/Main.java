//Luke Burgie
//Capstone Project

import java.util.*;
import java.util.Random;  //for random number generation


public class Main
{
	public static void main(String[] args) {
		//Welcome Header
		System.out.println("Welcome to Blackjack!");
		System.out.println("Dealer will hold at 17");
		
		//initialize variables  
		int playGame = 1;
		int playerWins = 0;
		double gamesPlayed = 0;
		double winPercent = 0.0;
		Random randGen = new Random();
		
		
		while(playGame == 1){
		 if (playerWins == 0){
		     System.out.println("You have not won a game yet!");
		     System.out.println();
		 }
		 else{
		     winPercent = (playerWins/gamesPlayed) * 100;
		     System.out.println("PLayer wins: " + playerWins );
		     System.out.println("Your Win ratio is " + winPercent +"%");
		     System.out.println();
		 }
		 
		 //add 1 to gamesPlayed
		 gamesPlayed += 1; 
		 
		 //create deck
		 deck deck = new deck();
		 
		 
		 //draw cards for dealer
		 ArrayList<card> dealerHand = new ArrayList<>();// will hold cards removed from deck
		 
		 int cardPull = randGen.nextInt((deck.size() - 1));
		 dealerHand.add(deck.drawCard(cardPull));
		 
		 cardPull = randGen.nextInt((deck.size() - 1));
		 dealerHand.add(deck.drawCard(cardPull));
		 
		 int dealerScore = 0; //sum of dealerHand
		 
		 for (int i = 0; i < dealerHand.size(); i++){
		     card currentCard = dealerHand.get(i);
		     dealerScore = dealerScore + currentCard.getValue();
	 	     //System.out.println("dealerScore =" + dealerScore); //for testing 
		 }
		 System.out.println("||| Dealer's Hand |||");
		 for (int i = 0; i < dealerHand.size(); i++){
		     card currentCard = dealerHand.get(i);
		     System.out.println(currentCard.getFace());
		
		 }
		 
		 
		 System.out.println(); //show dealerHand
		 
		 
		 //draw cards for player
		 ArrayList<card> playerHand = new ArrayList<>();// will hold cards removed from deck
		 
		 cardPull = randGen.nextInt((deck.size() - 1));
		 playerHand.add(deck.drawCard(cardPull));
		 
		 cardPull = randGen.nextInt((deck.size() - 1));
		 playerHand.add(deck.drawCard(cardPull));
		 
		 int playerScore = 0;
		 
		 for (int i = 0; i < playerHand.size(); i++){
		     card currentCard = playerHand.get(i);
		     playerScore += currentCard.getValue();
		     //System.out.println("playerScore =" + playerScore); //for testing
		 }
		 
		 System.out.println("||| Your Hand |||");
		 for (int i = 0; i < playerHand.size(); i++){
		     card currentCard = playerHand.get(i);
		     System.out.println(currentCard.getFace());
		
		 }
		 
		 System.out.println();
		 
		 //player chooses to draw card or hold
		 System.out.print("Enter 1 to draw or 2 to hold: ");
		 System.out.println();
		 
		 Scanner input = new Scanner(System.in);
		 int playerChoice = input.nextInt();
		 
		 //runs if player choses to draw, repeats 
		 while (playerChoice == 1){
		        
		        cardPull = randGen.nextInt((deck.size() - 1));
		        playerHand.add(deck.drawCard(cardPull));
		        
		        card currentCard = playerHand.get(playerHand.size() - 1);
		        playerScore += currentCard.getValue(); 
		         
		         
		         System.out.println("||| Your Hand |||");
		         for (int i = 0; i < playerHand.size(); i++){
		           currentCard = playerHand.get(i);
		           System.out.println(currentCard.getFace());
		           //System.out.println("playerScore =" + playerScore ); //for testing
		
		 }
		         
		         System.out.print("Enter 1 to draw or 2 to hold: ");
		         
		         playerChoice = input.nextInt();
		         System.out.println();
		   
		 
		 }//end while playerChoice
		 
		 //runs if dealer score is below 17
		 while (dealerScore < 17){
		     cardPull = randGen.nextInt((deck.size() - 1));
		     dealerHand.add(deck.drawCard(cardPull));
		     
		     card currentCard = dealerHand.get(dealerHand.size() - 1);
		     dealerScore += currentCard.getValue();
		  
		 }//end while
		 
		  System.out.println("||| Dealer's Hand |||");
		 for (int i = 0; i < dealerHand.size(); i++){
		     card currentCard = dealerHand.get(i);
		     System.out.println(currentCard.getFace());
		
		 }
		 
		 //if else evaluates game winner
		 if (playerScore > 21){
		     System.out.println("You lose! Enter 1 to play again or any other number to quit!");
		     playGame = input.nextInt();
		 }//end if
		 
		 else if (dealerScore > 21){
		     System.out.println("YOU WIN! Enter 1 to play again or any other number to quit!");
		     playerWins += 1;
		     playGame = input.nextInt();
		 
		 }//end else if
		 
		 else if ( playerScore > dealerScore){
		     System.out.println("YOU WIN! Enter 1 to play again or any other number to quit!");
		     playerWins += 1;
		     playGame = input.nextInt();
		     
		 }//end else if
		 
		 else{
		     System.out.println("You lose! Enter 1 to play again or any other number to quit!");
		     playGame = input.nextInt();
		     
		 }//end else
	    
	}//end while playGame loop
	
	//runs when player chooses to quit
	System.out.println("Thanks for playing!");
	

	    
	}//end main

}//end class
