
public class card{
    
    String face; 
    
    int value; 
    
    card(String face, int value){
        this.face = face;
        this.value = value;
    }//end constuctor
    
    int getValue(){
        
        return value;
    }// end getValue()
    
    String getFace(){
        
        return face;
    }//getFace()
    
    
}//end class