import java.util.*;


public class deck{
    
    ArrayList<card> deck = new ArrayList<>();
    
    //constructor fills arraylist deck with cards
    deck(){
    
    //create cards
    String face = "Ace of Hearts";
    int value = 11;
    card c1 = new card(face,value);
    deck.add(c1);
    
        
    face = "2 of Hearts";
    value = 2;
    card c2 = new card(face,value);
    deck.add(c2);
   
    face = "3 of Hearts";
    value = 3;
    card c3 = new card(face,value);
    deck.add(c3);
    
    face = "4 of Hearts";
    value = 4;
    card c4 = new card(face,value);
    deck.add(c4);
    
    face = "5 of Hearts";
    value = 5;
    card c5 = new card(face,value);
    deck.add(c5);
    
    face = "6 of Hearts";
    value = 6;
    card c6 = new card(face,value);
    deck.add(c6);
    
    face = "7 of Hearts";
    value = 7;
    card c7 = new card(face,value);
    deck.add(c7);
    
    face = "8 of Hearts";
    value = 8;
    card c8 = new card(face,value);
    deck.add(c8);
    
    face = "9 of Hearts";
    value = 9;
    card c9 = new card(face,value);
    deck.add(c9);
    
    face = "10 of Hearts";
    value = 10;
    card c10 = new card(face,value);
    deck.add(c10);
    
    face = "Jack of Hearts";
    value = 10;
    card c11 = new card(face,value);
    deck.add(c11);
    
    face = "Queen of Hearts";
    value = 10;
    card c12 = new card(face,value);
    deck.add(c12);
    
    face = "King of Hearts";
    value = 10;
    card c13 = new card(face,value);
    deck.add(c13);
    
    face = "Ace of Spades";
    value = 11;
    card c14  = new card(face,value);
    deck.add(c14);
    
    face = "2 of Spades";
    value = 2;
    card c15 = new card(face,value);
    deck.add(c15);
    
    face = "3 of Spades";
    value = 3;
    card c16 = new card(face,value);
    deck.add(c16);
    
    face = "4 of Spades";
    value = 4;
    card c17 = new card(face,value);
    deck.add(c17);
    
    face = "5 of Spades";
    value = 5;
    card c18 = new card(face,value);
    deck.add(c15);
    
    face = "6 of Spades";
    value = 6;
    card c19 = new card(face,value);
    deck.add(c19);
    
    face = "7 of Spades";
    value = 7;
    card c20 = new card(face,value);
    deck.add(c20);
    
    face = "8 of Spades";
    value = 8;
    card c21 = new card(face,value);
    deck.add(c21);
    
    face = "9 of Spades";
    value = 9;
    card c22 = new card(face,value);
    deck.add(c22);
    
    face = "10 of Spades";
    value = 10;
    card c23 = new card(face,value);
    deck.add(c23);
    
    face = "Jack of Spades";
    value = 10;
    card c24 = new card(face,value);
    deck.add(c24);
    
    face = "Queen of Spades";
    value = 10;
    card c25 = new card(face,value);
    deck.add(c25);
    
    face = "King of Spades";
    value = 10;
    card c26 = new card(face,value);
    deck.add(c26);
    
    face = "Ace of Clubs";
    value = 11;
    card c27 = new card(face,value);
    deck.add(c27);
    
    face = "2 of Clubs";
    value = 2;
    card c28 = new card(face,value);
    deck.add(c28);
    
    face = "3 of Clubs";
    value = 3;
    card c29 = new card(face,value);
    deck.add(c29);
    
    face = "4 of Clubs";
    value = 4;
    card c30 = new card(face,value);
    deck.add(c30);
    
    face = "5 of Clubs";
    value = 5;
    card c31 = new card(face,value);
    deck.add(c31);
    
    face = "6 of Clubs";
    value = 6;
    card c32 = new card(face,value);
    deck.add(c32);
    
    face = "7 of Clubs";
    value = 7;
    card c33 = new card(face,value);
    deck.add(c33);
    
    face = "8 of Clubs";
    value = 8;
    card c34 = new card(face,value);
    deck.add(c34);
    
    face = "9 of Clubs";
    value = 9;
    card c35 = new card(face,value);
    deck.add(c35);
    
    face = "10 of Clubs";
    value = 10;
    card c36 = new card(face,value);
    deck.add(c36);
    
    face = "Jack of Clubs";
    value = 10;
    card c37 = new card(face,value);
    deck.add(c37);
    
    face = "Queen of Clubs";
    value = 10;
    card c38 = new card(face,value);
    deck.add(c38);
    
    face = "King of Clubs";
    value = 10;
    card c39 = new card(face,value);
    deck.add(c39);
    
    face = "Ace of Diamonds";
    value = 11;
    card c40 = new card(face,value);
    deck.add(c40);
    
    face = "2 of Diamonds";
    value = 2;
    card c41 = new card(face,value);
    deck.add(c41);
    
    face = "3 of Diamonds";
    value = 3;
    card c42 = new card(face,value);
    deck.add(c42);
    
    face = "4 of Diamonds";
    value = 4;
    card c43 = new card(face,value);
    deck.add(c43);
    
    face = "5 of Diamonds";
    value = 5;
    card c44 = new card(face,value);
    deck.add(c44);
    
    face = "6 of Diamonds";
    value = 6;
    card c45 = new card(face,value);
    deck.add(c45);
    
    face = "7 of Diamonds";
    value = 7;
    card c46 = new card(face,value);
    deck.add(c46);
    
    face = "8 of Diamonds";
    value = 8;
    card c47 = new card(face,value);
    deck.add(c47);
    
    face = "9 of Diamonds";
    value = 9;
    card c48 = new card(face,value);
    deck.add(c48);
    
    face = "10 of Diamonds";
    value = 10;
    card c49 = new card(face,value);
    deck.add(c49);
    
    face = "Jack of Diamonds";
    value = 10;
    card c50 = new card(face,value);
    deck.add(c50);
    
    face = "Queen of Diamonds";
    value = 10;
    card c51 = new card(face,value);
    deck.add(c51);
    
    face = "King of Diamonds";
    value = 10;
    card c52 = new card(face,value);
    deck.add(c52);
    
        
    }//end deck constructor
    
    card drawCard(int cardPull){
        card drawnCard = deck.get(cardPull);
        deck.remove(cardPull);
        
        return drawnCard;
    
        
    }//end drawCard
    
    int size(){
       
       int size = deck.size();
        return size;
   
    }//end size
    
}//end class
    