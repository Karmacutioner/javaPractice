import java.util.*;

public class Composition {
    
    public ArrayList<String> ParagraphList = new ArrayList<>();
    
    Paragraph allSentences = new Paragraph();
    
    //adds current Paragraph to paragraph list
    void addParagraph(){
    
        ParagraphList.add(allSentences.something);
        
        //earases current paragraph
        allSentences.clear();
    }// end addParagraph
    
    //iniates user input of sentence 
    void addSentence(){
        allSentences.addSentence();
    
    }//end addSentence
    
    //prints all paragraphs 
    void print(){
        
        ParagraphList.add(allSentences.something);
        
        
        System.out.println();
        for (String element : ParagraphList) {
         System.out.println(element);
         System.out.println();
        
        }
        
    }//end print
    
}//end class