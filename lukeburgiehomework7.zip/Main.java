//Homework 7
//Luke Burgie
//July 4 2024
//CSC1060
//Compostion writer

//for keyboard input
import java.util.*;

public class Main
{
    
    
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		int menuSelection = 0;
		
		Composition allParagraphs = new Composition();
		
		//Prints menu
		while (menuSelection != 4){
		 System.out.println("This program allows a user to enter a written compositon in pieces:");
		 System.out.println("1. Enter a new sentence.");
		 System.out.println("2. Start a new paragraph.");
		 System.out.println("3. Print the compostion.");
		 System.out.println("4. Quit");
		 System.out.print("Your menu selection is:");
		
		 // Takes menu selection
		 menuSelection = input.nextInt();
		 
		 //runs given menu selection
		 switch (menuSelection){
		     case 1:
		         allParagraphs.addSentence();
		         break;
		     case 2:
		         allParagraphs.addParagraph();
		         break;
		     case 3:
		         allParagraphs.print();
		         break;
		     case 4:
		         System.out.print("Goodbye");
		         break;
		 }//end switch for menuSelection
	
		}//end while loop for menuSelection
	
	    
	}//end main

    
}//end class

