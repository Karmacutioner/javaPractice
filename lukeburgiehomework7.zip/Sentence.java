

public class Sentence{
    
    public String sentence;
    
    public String setSentence(String line){
        String sentence = line;
        return sentence;
    }
        
}//end class