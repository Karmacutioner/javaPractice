import java.util.*;

public class Paragraph{
    
    
    //ArrayList for storing sentences
    public ArrayList<String> SentenceList = new ArrayList<>();
    
    String something = SentenceList.toString();
   
    
    //takes user input for new sentence
    void addSentence(){
        
        Scanner add = new Scanner(System.in);
        System.out.println("Type a sentence then press Enter:");
        String line = add.nextLine();
    
        Sentence words = new Sentence();
        
        words.setSentence(line);
        
        SentenceList.add(line);
        
        something = SentenceList.toString();

    
    }//end addSentence
     
    public void clear(){
        SentenceList.clear();
        
    }//end clear
    
}//end class