// Homework 2
// Luke Burgie
// May 31 2024
// CSC1060
//This program takes and input of the desired size of the sun for a model solar system and calculates the scale size and distances of the planets  

import java.util.Scanner; //for keyboard input 

public class Main
{
	public static void main(String[] args) {
	//Constants
	final double SUN = 8.7E5;        //Actual diameter of the sun in miles
	final double MERCURY = 3.0E3;    //Actual diameter of Mercury in miles
	final double VENUS = 7.5E3;      //Actual diameter of Venus in miles
	final double EARTH = 8.0E3;      //Actual diameter of Earth in miles
	final double MARS = 4.222E3;     //Actual diameter of Mars in miles
	final double JUPITER = 8.6881E4; //Actual diameter of Jupiter in miles
	final double SATURN = 7.5E4;     //Actual diameter of Saturn in miles
	final double URANUS = 3.176E4;   //Actual diameter of Uranus in miles
	final double NEPTUNE = 3.0775E4; //Actual diameter of Neptune in miles
	final double PLUTO = 1.4E3;      //Actual diameter of Pluto in miles
		
	final double MER_DIST = 3.6E7;   //Actual Mercury distance from sun in miles
	final double VEN_DIST = 6.72E7;  //Actual Venus distance from sun in miles
	final double EAR_DIST = 9.3E7;   //Actual Earth distance from sun in miles
	final double MAR_DIST = 1.416E8; //Actual Mars distance from sun in miles
	final double JUP_DIST = 4.836E8; //Actual Jupiter distance from sun in miles 
	final double SAT_DIST = 8.867E8; //Actual Saturn distance from sun in miles 
	final double URA_DIST = 1.784E9; //Actual Uranus distance from sun in miles
	final double NEP_DIST = 2.7944E9;//Actual Neptune distance from sun in miles
	final double PLU_DIST = 3.6745E9;//Actual Pluto distance from sun in miles
		
		
		    //Takes user input to determine scale of model 
		    Scanner input = new Scanner(System.in);
		    System.out.println("What size will the sun be in inches?");
		    double modelSun = input.nextFloat(); 
		    double scale = modelSun / (SUN * 63360.0); 
		    
		    //Takes constant planet diameter variables, converts to inches and calculates planet model size
		    double modelMercury = (MERCURY * 63360.0) * scale;
		    double modelVenus = (VENUS * 63360.0) * scale;
		    double modelEarth = (EARTH * 63360.0) * scale;
		    double modelMars = (MARS * 63360.0) * scale;
		    double modelJupiter = (JUPITER * 63360.0) * scale;
		    double modelSaturn = (SATURN *63360.0) * scale;
		    double modelUranus = (URANUS * 63360.0) * scale;
		    double modelNeptune =(NEPTUNE * 63360.0) * scale;
		    double modelPluto = (PLUTO * 63360.0) * scale;
		    
		    //Takes constant distance variables, converts to inches and calulates planet model distances from sun
		    double modelMerDist = (MER_DIST * 63360.0) * scale;
		    double modelVenDist = (VEN_DIST * 63360.0) * scale;
		    double modelEarDist = (EAR_DIST * 63360.0) * scale;
		    double modelMarDist = (MAR_DIST * 63360.0) * scale;
		    double modelJupDist = (JUP_DIST * 63360.0) * scale;
		    double modelSatDist = (SAT_DIST * 63360.0) * scale;
		    double modelUraDist = (URA_DIST * 63360.0) * scale;
		    double modelNepDist = (NEP_DIST * 63360.0) * scale;
		    double modelPluDist = (PLU_DIST * 63360.0) * scale;
		    
		    //outputs model information
		    System.out.print("Scale model dimensions: Sun ");                                      // outputs sun model size
		    System.out.print(modelSun);
		    System.out.println(" inches");
		    System.out.println("Planet:     Diameter:      Distance:");
		    System.out.println("                           Inches     Feet      Yards      Miles");//Chart Header
		    System.out.print("Mercury     ");                                                      //Start Mercury output
		    System.out.printf("%.7f", modelMercury);
		    System.out.printf("      %.3f", modelMerDist);                                      
		    System.out.printf("    %.4f" , modelMerDist / 12);                                     //Convert distance to feet
		    System.out.printf("   %.5f" , modelMerDist / 36);                                      //Convert distance to yards
		    System.out.printf("    %.6f", modelMerDist / 63360);                                   //Convert distance to miles
		    System.out.println();
		    System.out.print("Venus       ");                                                      //Start Venus output
		    System.out.printf("%.7f", modelVenus);
		    System.out.printf("      %.3f", modelVenDist);                                      
		    System.out.printf("    %.4f" , modelVenDist / 12);                                     //Convert distance to feet
		    System.out.printf("   %.5f" , modelVenDist / 36);                                      //Convert distance to yards
		    System.out.printf("   %.6f", modelVenDist / 63360);                                    //Convert distance to miles
		    System.out.println();
		    System.out.print("Earth       ");                                                      //Start Earth output
	        System.out.printf("%.7f", modelEarth);  
		    System.out.printf("      %.3f", modelEarDist);                                      
		    System.out.printf("    %.4f" , modelEarDist / 12);                                     //Convert distance to feet
		    System.out.printf("   %.5f" , modelEarDist / 36);                                      //Convert distance to yards
		    System.out.printf("   %.6f", modelEarDist / 63360);                                    //Convert distance to miles
		    System.out.println();
		    System.out.print("Mars        ");                                                      //Start Mars Output
		    System.out.printf("%.7f", modelMars);
		    System.out.printf("      %.3f", modelMarDist);                                      
		    System.out.printf("   %.4f" , modelMarDist / 12);                                      //Convert distance to feet
		    System.out.printf("  %.5f" , modelMarDist / 36);                                       //Convert distance to yards
		    System.out.printf("   %.6f", modelMarDist / 63360);                                    //Convert distance to miles
		    System.out.println();
		    System.out.print("Jupiter     ");                                                      // Start Jupiter Output
		    System.out.printf("%.7f", modelJupiter);
		    System.out.printf("      %.3f", modelJupDist);                                      
		    System.out.printf("   %.4f" , modelJupDist / 12);                                      //Convert distance to feet
		    System.out.printf("  %.5f" , modelJupDist / 36);                                       //Convert distance to yards
		    System.out.printf("  %.6f", modelJupDist / 63360);                                     //Convert distance to miles
		    System.out.println();
		    System.out.print("Saturn      ");                                                      //Start Saturn output
	        System.out.printf("%.7f", modelSaturn);
		    System.out.printf("      %.3f", modelSatDist);                                      
		    System.out.printf("   %.4f" , modelSatDist / 12);                                      //Convert distance to feet
		    System.out.printf("  %.5f" , modelSatDist / 36);                                       //Convert distance to yards
		    System.out.printf("  %.6f", modelSatDist / 63360);                                     //Convert distance to miles
		    System.out.println();
		    System.out.print("Uranus      ");                                                      //Start Uranus output
		    System.out.printf("%.7f", modelUranus);
		    System.out.printf("      %.3f", modelUraDist);                                      
		    System.out.printf("  %.4f" , modelUraDist / 12);                                       //Convert distance to feet
		    System.out.printf(" %.5f" , modelUraDist / 36);                                        //Convert distance to yards
		    System.out.printf("  %.6f", modelUraDist / 63360);                                     //Convert distance to miles
		    System.out.println();
	        System.out.print("Neptune     ");                                                      //Start Neptune utput
	        System.out.printf("%.7f", modelNeptune);
		    System.out.printf("      %.3f", modelNepDist);                                      
		    System.out.printf("  %.4f" , modelNepDist / 12);                                       //Convert distance to feet
		    System.out.printf(" %.5f" , modelNepDist / 36);                                        //Convert distance to yards
		    System.out.printf("  %.6f", modelNepDist / 63360);                                     //Convert distance to miles
		    System.out.println();
		    System.out.print("Pluto       ");                                                      // Start Pluto output                                            
	        System.out.printf("%.7f", modelPluto);
		    System.out.printf("      %.3f", modelPluDist);                                      
		    System.out.printf("  %.4f" , modelPluDist / 12);                                       //Convert distance to feet
		    System.out.printf(" %.5f" , modelPluDist / 36);                                        //Convert distance to yards
		    System.out.printf("  %.6f", modelPluDist / 63360);                                     //Convert distance to miles
		    System.out.println();
	    
	}
}
