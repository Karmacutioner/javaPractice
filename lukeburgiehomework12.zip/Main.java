//Homework 12
//Luke Burgie
//July 4 2024
//CSC1060
//Recursion and Exception

import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;


public class Main
{
    public static void readDataFile() throws IOException{
    Scanner scnr = new Scanner(System.in);
		FileInputStream fileByteStream = null;
		Scanner inFS = null;
		
		String fileToOpen = null;
		
	    int recursiveCallCount = 0;
		
		boolean fileOpened = false;
		
		while (fileOpened == false){
		
		try{
		
		fileByteStream = new FileInputStream(fileToOpen);
		inFS = new Scanner(fileByteStream);
		
		fileOpened = true;
		 
		    
		}//end try
		
		catch(NullPointerException e){
		    
		    recursiveCallCount += 1;
		    System.out.println("Failed to open.");
		    System.out.println("Recursive call count:" + recursiveCallCount);
		    System.out.print("Enter correct file name: ");
		    fileToOpen = scnr.nextLine();
		
		    
		}//end catch
		
		
		catch(FileNotFoundException e){
		    
		    recursiveCallCount += 1;
		    System.out.println("Failed to open");
		    System.out.println("Recursive call count:" + recursiveCallCount);
		    System.out.print("Enter correct file name: ");
		    fileToOpen = scnr.nextLine();
		
		}   
		}//end while
		
		System.out.println("Thank you for fixing that.");
		
		while(recursiveCallCount > 0){
		    System.out.println("Recursion return count: " + recursiveCallCount);
		    recursiveCallCount -= 1;
		}
		
		
		System.out.println("This is the content of the file.");
		
		while (inFS.hasNextLine()){
		    String lineItem = inFS.nextLine();
		    System.out.println(lineItem);
		   
	
		}// end while
		fileByteStream.close();   
}//end readDataFile()	
	
	
	public static void main(String[] args) throws IOException{
		
		readDataFile();
	    
	}//end main
}//end class
